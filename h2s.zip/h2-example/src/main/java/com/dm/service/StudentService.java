package com.dm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.model.Student;
import com.dm.repository.StudentRepository;

//defining the business logic
@Service
public class StudentService {
	@Autowired
	StudentRepository studentRepository;

//getting all student records
	public List<Student> getAllStudent() {
		//Employee
		List<Student> students = (List<Student>) studentRepository.findAll();
		
		
		
		
		return students;
	}

//getting a specific record
	public Student getStudentById(int id) {
		// Student
		Student str =  studentRepository.findById(id).get();
		
		// Call Employee Trainservice
		//Ttraing srt = 
		
		//Model Student - Populate Employe + training 
		
		return str;
	}

	public void saveOrUpdate(Student student) {
		studentRepository.save(student);
	}

//deleting a specific record
	public void delete(int id) {
		studentRepository.deleteById(id);
	}
	
	
	public List<Student> getStudentbyName(String name) {
		
		List<Student> students = (List<Student>) studentRepository.findAll();
		
		//Search for a given Name -  Stream Api...
		//Find Student , Match the Name - GetName()
		List<Student> samenameStudents =  students.stream().filter(s -> s.getName().contains(name)).collect(Collectors.toList());
		
			
		samenameStudents.forEach( s -> System.out.println(s));
		return samenameStudents;
	}
}