package com.dm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.dm.model.Student;
import com.dm.repository.StudentPSRepository;

//defining the business logic
@Service
public class StudentPSService {
	@Autowired
	StudentPSRepository studentPSRepository;

//getting all student records
	public List<Student> getAllStudent(int pageSize) {
		List<Student> students = new ArrayList<Student>();
		Pageable firstPageWithTwoElements = PageRequest.of(0, pageSize);
		
		Page<Student> studentspageObj = (Page<Student>) studentPSRepository.findAllByName("asdas", firstPageWithTwoElements);
		System.out.println(studentspageObj.getTotalPages());
		
		return studentspageObj.getContent();
	}

}