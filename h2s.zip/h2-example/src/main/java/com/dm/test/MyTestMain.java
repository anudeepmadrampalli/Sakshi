package com.dm.test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;

public class MyTestMain {

	public static void main(String[] args) {
		
		List<EmployeeDM> empList = new ArrayList<>();
		
		EmployeeDM emp = new EmployeeDM();
		emp.setAge(10);
		emp.setLname("Baaa");
		emp.setName("Aaaa");
		empList.add(emp);
		
		emp = new EmployeeDM();
		emp.setAge(20);
		emp.setLname("Zaaa");
		emp.setName("Naaa");
		empList.add(emp);
		
		emp = new EmployeeDM();
		emp.setAge(30);
		emp.setLname("Laaa");
		emp.setName("Paaa");
		empList.add(emp);
		
		emp = new EmployeeDM();
		emp.setAge(8);
		emp.setLname("Yaaa");
		emp.setName("Faaa");
		empList.add(emp);
		
		emp = new EmployeeDM();
		emp.setAge(40);
		emp.setLname("Kaaa");
		emp.setName("Daaa");
		empList.add(emp);
		
		empList.forEach(item->System.out.println(item));
		
		System.out.println(".........Sorted Age............");
		Collections.sort(empList);		
		empList.forEach(item->System.out.println(item));
		
		System.out.println(".........Sorted Name............");
		Collections.sort(empList, new NameComparator());		
		empList.forEach(item->System.out.println(item));
//

//		
//		
		System.out.println(".........Sorted lname............");
		Comparator<EmployeeDM> employeeLNameComparator
	      = Comparator.comparing(EmployeeDM::getLname);	
		
		Comparator<EmployeeDM> employeeNameComparator
	      = Comparator.comparing(EmployeeDM::getName);	
		
		
		
		Collections.sort(empList, employeeNameComparator);			
		empList.forEach(item->System.out.println(item));
		
		EmployeeDMTest as = new EmployeeDMTest();
		EmployeeDM ad = new EmployeeDM();
		
		System.out.println(as);
		System.out.println("........Consumer");
		
		
		Consumer<EmployeeDM> c = System.out::println;
		c.accept(emp);
		
	}

}
