package com.dm.test;

import java.util.Date;

public class EmployeeDMTest {

	private Date currentTime;

	public Date getCurrentTime() {
		return currentTime;
	}

}
