package com.dm.test;

import java.util.Comparator;

class NameComparator implements Comparator<EmployeeDM> 
{ 

    public int compare(EmployeeDM a, EmployeeDM b) 
    { 
        return a.getName().compareTo(b.getName());
    } 
} 