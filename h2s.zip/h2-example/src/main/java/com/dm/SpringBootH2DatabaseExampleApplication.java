package com.dm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.dm.model.Student;
import com.dm.repository.StudentRepository;

@SpringBootApplication
public class SpringBootH2DatabaseExampleApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootH2DatabaseExampleApplication.class, args);

	
	}
}
