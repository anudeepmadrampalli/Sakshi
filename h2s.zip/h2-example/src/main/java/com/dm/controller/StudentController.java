package com.dm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dm.model.Student;
import com.dm.service.StudentPSService;
import com.dm.service.StudentService;

//creating RestController
@RestController
public class StudentController {
//autowired the StudentService class
	@Autowired
	StudentService studentService;
	
	@Autowired
	StudentPSService studentpsService;
	
	public static Logger LOGGER = LoggerFactory.getLogger(StudentController.class);

//creating a get mapping that retrieves all the students detail from the database 
	@GetMapping("/student")
	private List<Student> getAllStudent() {
		System.out.println("Hello Accessing students");
		LOGGER.info("This is my logger message");
		return studentService.getAllStudent();
	}
	
	@GetMapping("/student/stream/{name}")
	private List<Student> getStudentsByName(@PathVariable("name") String name) {

		return studentService.getStudentbyName(name);
	}

//creating a get mapping that retrieves the detail of a specific student
	@GetMapping("/student/{id}")
	private Student getStudent(@PathVariable("id") int id) {
		return studentService.getStudentById(id);
	}

//creating a delete mapping that deletes a specific student
	@DeleteMapping("/student/{id}")
	private void deleteStudent(@PathVariable("id") int id) {
		studentService.delete(id);
	}

//creating post mapping that post the student detail in the database
	@PostMapping("/student")
	private int saveStudent(@RequestBody Student student) {
		studentService.saveOrUpdate(student);
		return student.getId();
	}
	
	@GetMapping("/paging/students/{pageSize}")
	private List<Student> getAllPageBasedStudent(@PathVariable("pageSize") int pageSize) {
		System.out.println("Hello Accessing students");
		LOGGER.info("This is my logger message");
		return studentpsService.getAllStudent(pageSize);
	}
}
