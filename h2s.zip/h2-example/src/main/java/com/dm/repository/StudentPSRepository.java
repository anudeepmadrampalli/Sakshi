package com.dm.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dm.model.Student;

public interface StudentPSRepository extends JpaRepository<Student, Integer> {
	
	List<Student> findAllByName(String name, Pageable pageable);
	
	
}
