package com.dm.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.dm.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {
	
	List<Student> findByName(String name);
}
